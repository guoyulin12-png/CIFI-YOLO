import argparse

from ultralytics import YOLO

from model import register_modules


def parse_args():
    parser = argparse.ArgumentParser(description="Test CIFI-YOLO.")
    parser.add_argument("--weights", type=str, default="runs/CIFI/train/weights/best.pt", help="checkpoint path")
    parser.add_argument("--data", type=str, default="datasets/VisDrone.yaml", help="dataset YAML path")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--split", type=str, default="test", choices=["train", "val", "test"])
    return parser.parse_args()


def main():
    args = parse_args()
    register_modules()
    model = YOLO(args.weights)
    metrics = model.val(
        data=args.data,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        split=args.split,
    )
    print(metrics)


if __name__ == "__main__":
    main()

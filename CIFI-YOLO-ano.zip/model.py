from pathlib import Path
import math
import tempfile

import torch
import torch.nn as nn

try:
    from ultralytics import YOLO
    from ultralytics.nn.modules import Conv, DWConv
except Exception:  # pragma: no cover
    YOLO = None
    Conv = None
    DWConv = None


CIFI_YAML = """
nc: 80
scales:
  n: [0.33, 0.25, 1024]
  s: [0.33, 0.50, 1024]
  m: [0.67, 0.75, 768]
  l: [1.00, 1.00, 512]
  x: [1.00, 1.25, 512]

backbone:
  - [-1, 1, Conv, [64, 3, 2]]
  - [-1, 1, Conv, [128, 3, 2]]
  - [-1, 3, C2f_PC, [128, True]]
  - [-1, 1, IEM, [128]]
  - [-1, 1, Conv, [256, 3, 2]]
  - [-1, 6, C2f_PC, [256, True]]
  - [-1, 1, IEM, [256]]
  - [-1, 1, Conv, [512, 3, 2]]
  - [-1, 6, C2f_PC, [512, True]]
  - [-1, 1, IEM, [512]]
  - [-1, 1, SPPF, [512, 5]]

head:
  - [-1, 1, Conv, [256, 1, 1]]
  - [-1, 1, nn.Upsample, [None, 2, "nearest"]]
  - [[-1, 6], 1, GCSA_M, []]
  - [-1, 3, CIF, [256, True]]
  - [-1, 1, Conv, [128, 1, 1]]
  - [-1, 1, nn.Upsample, [None, 2, "nearest"]]
  - [[-1, 3], 1, GCSA_M, []]
  - [-1, 3, CIF, [128, True]]
  - [-1, 1, Conv, [128, 3, 2]]
  - [[-1, 14], 1, GCSA_M, []]
  - [-1, 3, CIF, [256, True]]
  - [-1, 1, Conv, [256, 3, 2]]
  - [[-1, 10], 1, GCSA_M, []]
  - [-1, 3, CIF, [512, True]]
  - [[18, 21, 24], 1, Detect, [nc]]
"""


def write_model_yaml(path="CIFI.yaml", nc=80):
    """Write the CIFI-YOLO model configuration to disk."""
    path = Path(path)
    text = CIFI_YAML.replace("nc: 80", f"nc: {nc}", 1)
    path.write_text(text, encoding="utf-8")
    return path


def register_modules():
    """Register custom modules in the Ultralytics task namespace."""
    if YOLO is None:
        raise ImportError("Install dependencies first: pip install -r requirements.txt")
    import ultralytics.nn.tasks as tasks

    for cls in (CIF, Bot_IAFF, iAFF, IEM, GCSA_M, C2f_PC, PC_Bottleneck, PartialConv):
        setattr(tasks, cls.__name__, cls)


def build_model(nc=80, yaml_path=None):
    """Build a CIFI-YOLO model.

    This helper assumes the Ultralytics parser used by the runtime supports the
    custom modules declared here. For exact reproduction, use the parser logic
    released with this project or insert the module-handling branches described
    in README.md.
    """
    register_modules()
    if yaml_path is None:
        yaml_path = Path(tempfile.gettempdir()) / "CIFI.yaml"
    yaml_path = write_model_yaml(yaml_path, nc=nc)
    return YOLO(str(yaml_path))


class CIF(nn.Module):
    """C2f-style contextual iterative fusion block."""

    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(Bot_IAFF(self.c, self.c, shortcut, g, e=1.0) for _ in range(n))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))


class Bot_IAFF(nn.Module):
    """Bottleneck with iterative adaptive feature fusion."""

    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = Conv(c1, c_, 3, 1)
        self.cv2 = Conv(c_, c2, 3, 1)
        self.add = shortcut and c1 == c2
        self.iaff = iAFF(c2)

    def forward(self, x):
        y = self.cv2(self.cv1(x))
        return self.iaff([x, y]) if self.add else y


class iAFF(nn.Module):
    """Iterative adaptive feature fusion."""

    def __init__(self, channels, r=4):
        super().__init__()
        inter_channels = int(channels // r)
        self.conv1 = nn.Conv2d(channels // 2, inter_channels, 1, 1, 0)
        self.bn1 = nn.GroupNorm(num_groups=1, num_channels=inter_channels)
        self.relu = nn.ReLU()
        self.conv2 = nn.Conv2d(inter_channels, channels // 2, 1, 1, 0)
        self.bn2 = nn.GroupNorm(num_groups=1, num_channels=channels // 2)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()
        self.c = channels // 2

    def forward(self, x):
        a = x[0] + x[1]
        y = list(a.split((self.c, self.c), 1))
        xa = y[0] + y[1]
        wei = self.sigmoid(xa + self.bn2(self.conv2(self.relu(self.bn1(self.conv1(self.pool(xa)))))))
        xi = y[0] * wei + y[1] * (1 - wei)
        wei2 = self.sigmoid(xi + self.bn2(self.conv2(self.relu(self.bn1(self.conv1(self.pool(xi)))))))
        xo = y[0] * wei2 + y[1] * (1 - wei2)
        return torch.cat((xi, xo), 1)


class IEM(nn.Module):
    """Information enhancement module with asymmetric and dilated branches."""

    def __init__(self, in_planes, out_planes, stride=1, scale=0.1, map_reduce=8):
        super().__init__()
        self.scale = scale
        inter_planes = in_planes // map_reduce
        self.branch4 = nn.Sequential(BasicConv(in_planes, inter_planes, 1, 1))
        self.branch1 = nn.Sequential(
            BasicConv(inter_planes, (inter_planes // 2) * 3, (1, 3), stride, padding=(1, 0)),
            BasicConv((inter_planes // 2) * 3, 2 * inter_planes, (3, 1), stride, padding=(0, 1)),
        )
        self.branch2 = nn.Sequential(BasicConv(inter_planes, 2 * inter_planes, 3, 1, padding=1, relu=False))
        self.branch3 = nn.Sequential(BasicConv(2 * inter_planes, 2 * inter_planes, 3, 1, padding=1, relu=False))
        self.conv_linear = BasicConv(in_planes, out_planes, 1, 1, relu=False)
        self.relu = nn.ReLU(inplace=False)
        self.dw = DWConv(in_planes, out_planes, k=1, s=1, act=False)
        self.kd = BasicConv(2 * inter_planes, 2 * inter_planes, 3, 1, padding=2, dilation=2, relu=False)
        self.kd2 = BasicConv(2 * inter_planes, 2 * inter_planes, 3, 1, padding=4, dilation=4, relu=False)

    def forward(self, x):
        x0 = self.branch4(x)
        residual = self.dw(x)
        x2 = self.branch1(x0)
        x21 = self.kd(x2)
        x22 = self.kd2(x2)
        x00 = self.branch2(x0)
        x01 = self.branch3(x00)
        out = torch.cat((torch.cat((x21, x00), 1), torch.cat((x22, x01), 1)), 1)
        out = self.conv_linear(out)
        return self.relu(out * self.scale + residual)


class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True,
                 bn=True, bias=False):
        super().__init__()
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size, stride, padding, dilation, groups, bias)
        self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.ReLU(inplace=True) if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x


class GCSA_M(nn.Module):
    """Gated channel-spatial aggregation for two feature maps."""

    def __init__(self, dim, dim2):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.conv_atten = nn.Sequential(nn.Conv2d(2 * (dim + dim2), dim + dim2, 1, bias=False), nn.Sigmoid())
        self.conv_redu = nn.Conv2d(dim + dim2, dim + dim2, 1, bias=False)
        self.conv1 = nn.Conv2d(dim, dim + dim2, 1, 1, bias=True)
        self.conv2 = nn.Conv2d(dim2, dim + dim2, 1, 1, bias=True)
        self.nonlin = nn.Sigmoid()

    def forward(self, m):
        x, skip = m
        output = torch.cat([x, skip], dim=1)
        att = self.conv_atten(torch.cat([self.avg_pool(output), self.max_pool(output)], dim=1))
        output = self.conv_redu(output * att)
        return output * self.nonlin(self.conv1(x) + self.conv2(skip))


class C2f_PC(nn.Module):
    """C2f block with partial-convolution bottlenecks."""

    def __init__(self, c1, c2, n=1, shortcut=False, g=4, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(PC_Bottleneck(self.c, self.c, shortcut, g, e=1.0) for _ in range(n))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))


class PC_Bottleneck(nn.Module):
    def __init__(self, c1, c2, shortcut=True, g=4, e=2):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = PartialConv(c1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(c_, c2, 1, 1, g=g)
        self.add = shortcut and c1 == c2
        self.bn = nn.BatchNorm2d(c_)
        self.relu = nn.ReLU()

    def forward(self, x):
        y = self.cv3(self.relu(self.bn(self.cv2(self.cv1(x)))))
        return x + y if self.add else y


class PartialConv(nn.Module):
    def __init__(self, dim, n_div=4, kernel_size=3):
        super().__init__()
        self.dim_conv3 = dim // n_div
        self.dim_untouched = dim - self.dim_conv3
        self.partial_conv3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, kernel_size, 1, 1, bias=False)

    def forward(self, x):
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        return torch.cat((self.partial_conv3(x1), x2), 1)


def autopad(k, p=None, d=1):
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class LocalConv(nn.Module):
    """Fallback Conv definition for reading this file without Ultralytics."""

    default_act = nn.SiLU()

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


if Conv is None:
    Conv = LocalConv

if DWConv is None:
    class DWConv(LocalConv):
        def __init__(self, c1, c2, k=1, s=1, d=1, act=True):
            super().__init__(c1, c2, k, s, g=math.gcd(c1, c2), d=d, act=act)

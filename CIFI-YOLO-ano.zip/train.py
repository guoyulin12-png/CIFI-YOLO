import argparse
from pathlib import Path

from ultralytics import YOLO

from model import register_modules, write_model_yaml


def parse_args():
    parser = argparse.ArgumentParser(description="Train CIFI-YOLO.")
    parser.add_argument("--data", type=str, default="datasets/VisDrone.yaml", help="dataset YAML path")
    parser.add_argument("--nc", type=int, default=10, help="number of classes")
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--optimizer", type=str, default="SGD")
    parser.add_argument("--project", type=str, default="runs/CIFI")
    parser.add_argument("--name", type=str, default="train")
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    register_modules()
    model_yaml = write_model_yaml(Path("CIFI.yaml"), nc=args.nc)
    model = YOLO(str(model_yaml))
    model.train(
        data=args.data,
        cache=False,
        imgsz=args.imgsz,
        epochs=args.epochs,
        batch=args.batch,
        resume=args.resume,
        single_cls=False,
        close_mosaic=0,
        device=args.device,
        optimizer=args.optimizer,
        amp=True,
        project=args.project,
        name=args.name,
    )


if __name__ == "__main__":
    main()

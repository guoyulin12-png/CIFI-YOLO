# CIFI-YOLO

Anonymous supplementary code for CIFI-YOLO. The package keeps only the core model definition, training script, testing script, dependency file, and this README. Experimental logs, datasets, cache files, virtual environments, and model weights are intentionally excluded.

## 1. Installation

```bash
pip install -r requirements.txt
```

The core model code is in `model.py`, including `CIF`, `IEM`, `GCSA_M`, and `C2f_PC`. The architecture uses 3.89M parameters, 30.4 GFLOPs, and 9.08 ms latency on RTX 3080 Ti in our evaluation setting. The model follows the YOLOv8 detection pipeline with P3, P4, and P5 output heads.

This anonymous package follows the requested compact format. For exact reproduction with Ultralytics, keep the custom module registration and parser handling for `CIF`, `IEM`, `GCSA_M`, and `C2f_PC`, as these modules are not included in the official Ultralytics release by default.

If a clean environment is required, create it first:

```bash
conda create -n cifi python=3.8 -y
conda activate cifi
pip install -r requirements.txt
```

For exact dependency export from your own training environment, run:

```bash
pip freeze > requirements.txt
```

## 2. Data Preparation

Place datasets under the project directory:

```text
datasets/
  VisDrone/
    train/images/
    train/labels/
    val/images/
    val/labels/
    test/images/
    test/labels/
  UAV-DT/
    train/images/
    train/labels/
    val/images/
    val/labels/
    test/images/
    test/labels/
  CODrone/
    train/images/
    train/labels/
    val/images/
    val/labels/
    test/images/
    test/labels/
```

Create a dataset YAML file, for example `datasets/VisDrone.yaml`:

```yaml
path: datasets/VisDrone
train: train/images
val: val/images
test: test/images
names:
  0: pedestrian
  1: people
  2: bicycle
  3: car
  4: van
  5: truck
  6: tricycle
  7: awning-tricycle
  8: bus
  9: motor
```

## 3. Training

Default training:

```bash
python train.py
```

Equivalent explicit command:

```bash
python train.py --data datasets/VisDrone.yaml --nc 10 --epochs 200 --imgsz 640 --batch 8 --device 0 --optimizer SGD --project runs/CIFI --name train
```

For CODrone, set the number of classes to 12:

```bash
python train.py --data datasets/CODrone.yaml --nc 12 --epochs 200 --imgsz 640 --batch 8 --device 0
```

Training outputs are saved under `runs/CIFI/`. This directory is ignored by GitHub and should not be uploaded.

## 4. Testing

Default testing:

```bash
python test.py
```

Explicit testing command:

```bash
python test.py --weights runs/CIFI/train/weights/best.pt --data datasets/VisDrone.yaml --imgsz 640 --batch 16 --device 0 --split test
```

For anonymous upload, push only these files:

```text
model.py
train.py
test.py
requirements.txt
README.md
.gitignore
```

Do not upload datasets, `runs/`, logs, caches, virtual environments, or large weight files. After creating an anonymous repository, copy the repository URL and use it as the code link in the manuscript response, for example:

```text
The anonymous code has been released at: https://github.com/anonymous-user/CIFI-YOLO
```
